
@include('inc/header')

@yield('content')

@include('inc/footer')