@extends('main')

@section('title')
    Form
@endsection

@section('content')
    <section class="wrp">
        <div class="cntr">
            {{-- form --}}
            <form action="/forms" method="POST" class="todo_form">
                {{ csrf_field() }}
                {{-- <div class="grp">
                    <input type="text" name="task_title" id="task_title" placeholder="Enter Title">
                </div> --}}
                <div class="grp">
                    <table class="memo" width="400">
                        <tbody>
                            Records: {{ count($forms) }}
                            @if (count($forms) > 0 )
                                @foreach ($forms as $list)
                                    @if (empty($list->title))
                                        @php
                                            $empty = "border-color: red"
                                        @endphp
                                    @else
                                        @php
                                            $empty = ""
                                        @endphp
                                    @endif
                                    <tr style="{{ $empty }}">
                                        <td>
                                            <input type="hidden" name="task_id[]" value="{{ $list->id }}">
                                            <input type="checkbox" name="task_item_check" class="task_item_check">
                                        </td>
                                        <td>
                                            <input type="text" value="{{ $list->title }}" placeholder="Task" name="task_title[]">
                                        </td>
                                        <td>
                                            <select name="task_status[]" value="{{ $list->status }}">
                                                <option value="Pending" @if( $list->status == "Pending") {{ "selected" }} @endif>Pending</option>
                                                <option value="Done" @if( $list->status == "Done") {{ "selected" }} @endif>Done</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="task_priority[]" value="{{ $list->priority }}">
                                                <option value="Low" @if( $list->priority == "Low") {{ "selected" }} @endif>Low</option>
                                                <option value="Medium" @if( $list->priority == "Med") {{ "selected" }} @endif>Med</option>
                                                <option value="High" @if( $list->priority == "High") {{ "selected" }} @endif>High</option>
                                            </select>
                                            
                                        </td>
                                        <td>
                                            <input type="date" placeholder="Due Date" name="task_ddate[]" value="{{ date("m-d-yy", $list->duedate) }}">
                                        </td>
                                        <td><input type="text" placeholder="Assignee" name="task_assignee[]" value="{{ $list->assignee }}"></td>
                                        <td><textarea name="task_notes[]" placeholder="Notes">{{ nl2br($list->notes) }}</textarea></td>
                                        <td><a href="#" class="btn close" data-attr="{{$list->id}}" data-token="{{ csrf_token() }}"><i class="fa fa-close"></i></a></td>
                                    </tr>
                                @endforeach
                                
                            @endif
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-memo" id="add_memo"><i class="fa fa-plus"></i> Add List</button>
                </div>
                <button type="submit" class="btn btn-memo btn-memo-save" id="save_memo"><i class="fa fa-save"></i> </button>
            </form>
            {{-- //form --}}
            
            {{ Session::get('message') }}
        </div>
    </section>
@endsection