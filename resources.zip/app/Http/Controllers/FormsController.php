<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Redirect;
use DB;
use App\Form;

class FormsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $form = \DB::select('select * from forms');
        return view('pages/form', ['forms'=>$form]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = $request->input('task_id');
        $task_title = $request->input('task_title');
        $task_status = $request->input('task_status');
        $task_priority = $request->input('task_priority');
        $task_ddate = $request->input('task_ddate');
        $task_assignee = $request->input('task_assignee');
        $task_notes = $request->input('task_notes');

        $form_model = new Form;  

        $flag = 0;
        $msg = array();

            $list_arr = [];
            for($i = 0; $i < count($id); $i++) {
                $forms = new Form;
                $forms->title = $task_title[$i];
                $forms->status = $task_status[$i];
                $forms->priority = $task_priority[$i];
                $forms->duedate = strtotime($task_ddate[$i]);
                $forms->assignee = $task_assignee[$i];
                $forms->notes = $task_notes[$i];

                if(!empty($task_title[$i])) {
                    if(!empty($id[$i])) {
                        Form::where('id',$id[$i])->update(
                                [
                                    "title"     => $task_title[$i], 
                                    "status"    => $task_status[$i],
                                    "priority"  => $task_priority[$i],
                                    "duedate"   => strtotime($task_ddate[$i]),
                                    "assignee"  => $task_assignee[$i],
                                    "notes"     => $task_notes[$i]
                                ]
                            );
                        $msg = array("msg"=>"Successfully updated!");
                    }else{
                        // add
                        $saved = $form_model->formMemo($forms);
                        if($saved) {
                            $msg = array("msg"=>"Successfully saved!");
                        }else{
                            $msg = array("msg"=>"Something went wrong! Please try again later.");
                        }
                    }

                }else{
                    $msg = array("msg"=> "Successfully saved!");
                }
            }
            

        
        return \Redirect::to('forms')->with('message', json_encode($msg));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $form = Form::find($id);
    
        if($form->delete($id)) {
            return json_encode(array(
                'success' => true,
                'msg'   => 'Data successfully deleted!'
            ));
        }
        
    }
}
