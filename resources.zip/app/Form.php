<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Form;
class Form extends Model
{
    public function formMemo($forms) {
        return $forms->save();
    }
}
